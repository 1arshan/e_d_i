from django.apps import AppConfig


class SubjectMaterialConfig(AppConfig):
    name = 'subject_material'
