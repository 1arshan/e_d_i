from django.apps import AppConfig


class BroadcasterConfig(AppConfig):
    name = 'broadcaster'
